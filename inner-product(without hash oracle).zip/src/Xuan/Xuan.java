package Xuan;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;


import static java.lang.System.out;

public class Xuan {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        Properties vPro = loadPropFromFile(vectorFile);
        String g1str=PProp.getProperty("g1");
        String g2str=PProp.getProperty("g2");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Element alpha = bp.getZr().newRandomElement().getImmutable();
        Element[] t = new Element[n+1];
        Element[] b = new Element[n+1];
        Element[] s = new Element[n+1];
        Element[] H = new Element[n+1];
        Element[] theta = new Element[n+1];
        mskProp.setProperty("alpha",alpha.toString());
        for (int  i = 1; i <= n; i++)
        {
            t[i] = bp.getZr().newRandomElement().getImmutable();
            b[i] = g1.powZn(t[i]);
            vPro.setProperty("t"+i,t[i].toString());
            PProp.setProperty("b"+i,b[i].toString());
            mskProp.setProperty("t"+i,t[i].toString());
        }

        for (int i = 1; i<=n; i++)
        {
            theta[i] = bp.getZr().newRandomElement().getImmutable();
            vPro.setProperty("theta"+i,theta[i].toString());
            PProp.setProperty("theta"+i,theta[i].toString());
        }

        Element G = bp.pairing(g1,g2);
        PProp.setProperty("G",G.toString());
        for (int i = 1; i <= n; i++)
        {
            s[i] = bp.getZr().newRandomElement().getImmutable();
            H[i] = G.powZn(s[i]);
            vPro.setProperty("s"+i,s[i].toString());
            PProp.setProperty("H"+i,H[i].toString());
            mskProp.setProperty("s"+i,s[i].toString());
        }
        PProp.setProperty("g1",g1.toString());
        PProp.setProperty("g2",g2.toString());




        storePropToFile(PProp,paramsFile);
        storePropToFile(vPro,vectorFile);
        storePropToFile(mskProp, mskFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);

        Element []H = new Element[n+1];
        Element []b = new Element[n+1];
        for (int i = 1; i <= n; i++)
        {
            String Hstr=PProp.getProperty("H"+i);
            H[i] = bp.getG1().newElementFromBytes(Hstr.getBytes()).getImmutable();
        }

        String Gstr = PProp.getProperty("G");
        Element G = bp.getG1().newElementFromBytes(Gstr.getBytes()).getImmutable();
        Element r =bp.getZr().newRandomElement().getImmutable();

        Element[] xi = new Element[n];
        for (int i = 1; i <= n; i++)
        {
            xi[i-1] = bp.getZr().newElementFromBytes(String.valueOf(x[i-1]).getBytes()).getImmutable();
            vPro.setProperty("x"+i,xi[i-1].toString());
            Element CT = H[i].powZn(r).mulZn(G.powZn(xi[i-1]));
            CTProp.setProperty("CT"+i,CT.toString());
        }
        for (int i = 1; i <= n; i++)
        {
            String bstr=PProp.getProperty("b"+i);
            b[i] = bp.getG1().newElementFromBytes(bstr.getBytes()).getImmutable();
            CTProp.setProperty("br"+i,b[i].powZn(r).toString());
        }

        randomPro.setProperty("r", r.toString());

        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Element [] theta = new Element[n+1];
        Element [] s = new Element[n+1];
        Element [] t = new Element[n+1];
        Element [] b = new Element[n+1];

        for (int i = 1; i <=n; i++)
        {
            String thetastr = PProp.getProperty("theta"+i);
            theta[i] = bp.getZr().newElementFromBytes(thetastr.getBytes()).getImmutable();
            String tstr = vPro.getProperty("t"+i);
            t[i] = bp.getZr().newElementFromBytes(tstr.getBytes()).getImmutable();
            String sstr = vPro.getProperty("s"+i);
            s[i] = bp.getZr().newElementFromBytes(sstr.getBytes()).getImmutable();
            String bstr = PProp.getProperty("b"+i);
            b[i] = bp.getZr().newElementFromBytes(bstr.getBytes()).getImmutable();
        }




        Element[] yi = new Element[n];
        yi[0] = bp.getZr().newElementFromBytes(String.valueOf(y[0]).getBytes()).getImmutable();

        vPro.setProperty("y0",yi[0].toString());

        for (int i = 1; i <= n; i++)
        {
            yi[i-1] = bp.getZr().newElementFromBytes(String.valueOf(y[i-1]).getBytes()).getImmutable();
            vPro.setProperty("y"+i,yi[i-1].toString());

        }

        Element c = s[1].mulZn(yi[0]).div(t[1].mul(theta[1])),tk = s[1].mulZn(yi[0]).div(t[1].mul(theta[1]));

        for (int i = 2; i <= n; i++)
        {
            tk = tk.mul(s[i].mul(yi[i-1]).div(t[i].mul(theta[i])));
        }
        Element g1sx = b[1].powZn(tk.mul(theta[1]));
        for (int i = 2;i<=n;i++)
            g1sx = g1sx.mulZn(b[i].powZn(tk.mul(theta[i])));
        Element sk = g2.powZn(tk);
        skProp.setProperty("sk",sk.toString());

        randomProp.setProperty("g1sx",g1sx.toString());
        randomProp.setProperty("tk",tk.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }



    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);

        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        Element[] x = new Element[n+1];
        Element[] y = new Element[n+1];
        Element[] b = new Element[n+1];
        Element[] CT = new Element[n+1];
        Element[] theta = new Element[n+1];
        String skstr = skProp.getProperty("sk");
        Element sk = bp.getG1().newElementFromBytes(skstr.getBytes()).getImmutable();
        for(int i = 0; i < n; i++)
        {

            String ystr=vPro.getProperty("y"+i);

            y[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();
        }
        for (int i = 1; i<= n; i++)
        {
            String CTstr = CTProp.getProperty("CT"+i);
            CT[i] = bp.getG1().newElementFromBytes(CTstr.getBytes()).getImmutable();
        }
        Element E1 = CT[1].powZn(y[0]);
        for (int i = 2; i <= n; i++)
        {

            E1 = E1.mulZn(CT[i].powZn(y[i-1]));
        }
        for (int i = 1; i <= n; i++)
        {
            String bstr = PProp.getProperty("b"+i);
            b[i] = bp.getG1().newElementFromBytes(bstr.getBytes()).getImmutable();
            String thetastr = PProp.getProperty("b"+i);
            theta[i] = bp.getZr().newElementFromBytes(thetastr.getBytes()).getImmutable();
        }

        String rstr = randomProp.getProperty("r");
        Element r = bp.getZr().newElementFromBytes(rstr.getBytes()).getImmutable();
        Element E2 = b[1].powZn(r).powZn(theta[1]);
        for (int i = 2; i <= n;i++)
        {
            E2 = E2.mulZn(b[i].powZn(r)).powZn(theta[i]);
        }
        Element E3 = bp.pairing(E2,sk);
        Element E = E1.mulZn(E3.invert());

        Element EM = bp.pairing(g1,g2).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (E.isEqual(bp.pairing(g1,g2).powZn(EM))) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }



    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Xuan/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 50;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(30)+0;
            y[i] = rand.nextInt(30)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,n);
        long end3 = System.currentTimeMillis();
        System.out.println(end3-start3);

//        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M, ID);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);

    }


}