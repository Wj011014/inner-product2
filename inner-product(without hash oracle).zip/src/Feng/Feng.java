package Feng;


import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;


import static java.lang.System.out;


public class Feng {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element  w = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  v = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  t = bp.getZr().newRandomElement().getImmutable();


        Element e = bp.pairing(g1,g2);
        Element h1 = g1.powZn(w);
        Element h2 = g2.powZn(v);
        Element k1 = g1.powZn(s).mul(h1.powZn(t));

        mskProp.setProperty("s", Base64.getEncoder().encodeToString(s.toBytes()));//element和string类型之间的转换需要通
        mskProp.setProperty("t", Base64.getEncoder().encodeToString(t.toBytes()));


        //设置公共参数

        PProp.setProperty("g1", g1.toString());
        mskProp.setProperty("g2",g2.toString());
        PProp.setProperty("h1", h1.toString());
        PProp.setProperty("h2", h2.toString());
        PProp.setProperty("e", e.toString());
        PProp.setProperty("k1", k1.toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,  String ID,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);
        Element r = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG2().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG2().newElementFromBytes(g2str.getBytes()).getImmutable();
        String estr=PProp.getProperty("e");
        Element e = bp.getG2().newElementFromBytes(estr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String k1str=PProp.getProperty("k1");
        Element k1 = bp.getG1().newElementFromBytes(k1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();


        Element C = g1.powZn(r).getImmutable();
        Element D = bp.pairing(h1,h2).powZn(r).getImmutable();
        byte[] ID0 =sha0(ID);
        Element ID1 = bp.getZr().newElementFromHash(ID0,0,ID0.length).getImmutable();
        Element E = bp.pairing(k1, g2.powZn(ID1)).powZn(r).getImmutable();

        Element[] xi = new Element[n];
        for (int i = 0; i < n; i++)
        {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            CTProp.setProperty("E"+i+ID, E.mulZn(e.powZn(xi[i])).getImmutable().toString());
            vPro.setProperty("x"+i,xi[i].toString());
        }


        randomPro.setProperty("r", r.toString());
        CTProp.setProperty("C"+ID, C.toString());
        CTProp.setProperty("D"+ID, D.toString());


        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,String ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String sstr=mskProp.getProperty("s");
        Element s = bp.getZr().newElementFromBytes(sstr.getBytes()).getImmutable();
        String tstr=mskProp.getProperty("t");
        Element t = bp.getZr().newElementFromBytes(tstr.getBytes()).getImmutable();

        byte[] ID0 =sha0(ID);
        Element ID1 = bp.getZr().newElementFromHash(ID0,0,ID0.length).getImmutable();

        Element[] yi = new Element[n];
        Double sum = 0.0;
        for (int i = 0; i < n; i++)
        {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            sum+=Double.valueOf(String.valueOf(ID1.mul(yi[i])));
            vPro.setProperty("y"+ID+i,yi[i].toString());
        }
        Element d1 = g2.powZn(bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable()).powZn(s.invert());
        Element d2 = t.invert().mul(bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable());
        skProp.setProperty("d1"+ID,d1.toString());
        skProp.setProperty("d2"+ID,d2.toString());


        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }

    public static void ReKeyGen(String paramsFile,String pairingFile,String skFile,String ID, String ID1)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Element t1 = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element r = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String k1str=PProp.getProperty("k1");
        Element k1 = bp.getG1().newElementFromBytes(k1str.getBytes()).getImmutable();
        String estr=PProp.getProperty("e");
        Element e = bp.getG1().newElementFromBytes(estr.getBytes()).getImmutable();
        String d1str=skProp.getProperty("d1"+ID);
        String d2str=skProp.getProperty("d2"+ID);
        Element d1 = bp.getZr().newElementFromBytes(d1str.getBytes()).getImmutable();
        Element d2 = bp.getZr().newElementFromBytes(d2str.getBytes()).getImmutable();


        byte[] ID0 =sha0(ID1);
        Element ID2 = bp.getZr().newElementFromHash(ID0,0,ID0.length).getImmutable();

        Element C = g1.powZn(r).getImmutable();
        Element D = bp.pairing(h1,h2).powZn(r).getImmutable();
        Element E = e.powZn(t1.mul(r)).mulZn(bp.pairing(k1,g2.powZn(ID2))).powZn(r).getImmutable();

        skProp.setProperty("rk1",d1.mulZn(g2.powZn(t1)).toString());
        skProp.setProperty("rk2",d2.toString());
        skProp.setProperty("rk31",C.toString());
        skProp.setProperty("rk32",D.toString());
        skProp.setProperty("rk33",E.toString());

        storePropToFile(skProp, skFile);


    }

    public static void ReEnc(String paramsFile,String pairingFile,String skFile,String CTFile,String ID, String ID1, int n, double[] y)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties CTProp =loadPropFromFile(CTFile);
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=PProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String rk1str=skProp.getProperty("rk1");
        Element rk1 = bp.getG1().newElementFromBytes(rk1str.getBytes()).getImmutable();
        String rk2str=skProp.getProperty("rk2");
        Element rk2 = bp.getG1().newElementFromBytes(rk2str.getBytes()).getImmutable();
        String rk31str=skProp.getProperty("rk31");
        Element rk31 = bp.getZr().newElementFromBytes(rk31str.getBytes()).getImmutable();
        String rk32str=skProp.getProperty("rk32");
        Element rk32 = bp.getG1().newElementFromBytes(rk32str.getBytes()).getImmutable();
        String rk33str=skProp.getProperty("rk33");
        Element rk33 = bp.getG1().newElementFromBytes(rk33str.getBytes()).getImmutable();
        String Cstr=CTProp.getProperty("C"+ID);
        Element C = bp.getG1().newElementFromBytes(Cstr.getBytes()).getImmutable();
        String Dstr=CTProp.getProperty("D"+ID);
        Element D = bp.getZr().newElementFromBytes(Dstr.getBytes()).getImmutable();
        Element[] E = new Element[n];
        for (int i = 0; i < n;i++)
        {
            String Estr=CTProp.getProperty("E"+i+ID);
            E[i] = bp.getZr().newElementFromBytes(Estr.getBytes()).getImmutable();
        }
        Element C1 = bp.pairing(C,rk1).mulZn(D.powZn(rk2)).getImmutable();
        for (int i = 0; i < n; i++)
        {
          C1 = C1.mulZn(E[i].powZn(bp.getG1().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable()));
        }
        CTProp.setProperty("C1"+ID1, C1.toString());
        CTProp.setProperty("D11"+ID1,rk31.toString());
        CTProp.setProperty("D12"+ID1, rk32.toString());
        CTProp.setProperty("D13"+ID1, rk33.toString());

        storePropToFile(CTProp, CTFile);


    }

    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String Cstr=CTProp.getProperty("C"+ID);
        Element C = bp.getG1().newElementFromBytes(Cstr.getBytes()).getImmutable();
        String Dstr=CTProp.getProperty("D"+ID);
        Element D = bp.getZr().newElementFromBytes(Dstr.getBytes()).getImmutable();
        String d1str=skProp.getProperty("d1"+ID);
        Element d1 = bp.getG1().newElementFromBytes(d1str.getBytes()).getImmutable();
        String d2str=skProp.getProperty("d2"+ID);
        Element d2 = bp.getG1().newElementFromBytes(d2str.getBytes()).getImmutable();

        Element[] x = new Element[n];
        Element[] E = new Element[n];
        Element[] y = new Element[n];
        Element[] y1 = new Element[n];
        for (int i = 0; i< n;i++)
        {
            String Estr=CTProp.getProperty("E"+i+ID);
            E[i] = bp.getG1().newElementFromBytes(Estr.getBytes()).getImmutable();
        }
        Element IP = bp.pairing(C,d1).mulZn(D.powZn(d2)).getImmutable();

        for(int i = 0; i < n; i++)
        {
            String ystr=vPro.getProperty("y"+i);
            IP = IP.mulZn(E[i].powZn(bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable()));
        }


//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        long start = System.currentTimeMillis();
        String dir = "./storeFile/Feng/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 50;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User1";
        String ID1="User2";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(30)+0;
            y[i] = rand.nextInt(30)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1+"setup");
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2+"enc");
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID,n);
        long end3 = System.currentTimeMillis();
        System.out.println(end3-start3+"KeyGen");
        long start4 = System.currentTimeMillis();
        ReKeyGen(ParameterFileName,pairingParametersFileName,skFileName,ID,ID1);
        long end4 = System.currentTimeMillis();
        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        ReEnc(ParameterFileName,pairingParametersFileName,skFileName,CTFileName,ID,ID1,n,y);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);
        long start6 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M,ID);
        long end6 = System.currentTimeMillis();
        System.out.println(end6-start6+"Dec");
        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }


}
