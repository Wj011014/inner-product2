package Ours;

import com.sun.xml.internal.bind.v2.model.core.ID;
import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;

import java.io.*;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;


import static java.lang.System.out;
import static java.lang.System.setOut;


public class Ours {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        //设置主私钥
        Element  alpha = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  h1 = bp.getG1().newRandomElement().getImmutable();//从Zq上任选一个数
        Element  h2 = bp.getG1().newRandomElement().getImmutable();//从Zq上任选一个数

        Element e = bp.pairing(g,g);
        Element g1 = g.powZn(alpha);

        mskProp.setProperty("s1_", Base64.getEncoder().encodeToString(alpha.toBytes()));//element和string类型之间的转换需要通

        //设置公共参数
        //long sta = System.nanoTime();
        //long end = System.nanoTime();
        // out.println(end-sta);
        PProp.setProperty("g1", g1.toString());
        mskProp.setProperty("alpha",alpha.toString());
        PProp.setProperty("h1", h1.toString());
        PProp.setProperty("h2", h2.toString());
        PProp.setProperty("e", e.toString());
        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
        storePropToFile(vPro, vectorFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile, String CTFile, String randomFile,  String ID,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomPro = loadPropFromFile(randomFile);
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数
        String gstr=PProp.getProperty("g");
        Element g = bp.getG2().newElementFromBytes(gstr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        Element ID1 = bp.getZr().newElementFromBytes(ID.getBytes()).getImmutable();
        Element C1 = g1.powZn(s).mul(g.powZn(s.mul(ID1)));
        Element C2 = bp.pairing(g.powZn(s),g);
        Element Cx = bp.pairing(g.powZn(s.invert()),g).mulZn(bp.pairing(g,g));

        Element[] xi = new Element[n];
        for (int i = 0; i < n; i++)
        {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            Cx= Cx.powZn(xi[i]);
            vPro.setProperty("x"+i,xi[i].toString());
        }

        byte[] beta0 =sha0(C1.toString()+C2.toString()+Cx.toString());
        Element beta = bp.getZr().newElementFromHash(beta0,0,beta0.length).getImmutable();
        Element C3 = bp.pairing(g.powZn(s.mul(beta)),h1).mulZn(bp.pairing(g,h2.powZn(s)));

        randomPro.setProperty("s", s.toString());
        CTProp.setProperty("C1"+ID, C1.toString());
        CTProp.setProperty("C2"+ID, C2.toString());
        CTProp.setProperty("C3"+ID, C3.toString());
        CTProp.setProperty("Cx"+ID, Cx.toString());

        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,String ID,int n)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String alphastr=mskProp.getProperty("alpha");
        Element alpha = bp.getZr().newElementFromBytes(alphastr.getBytes()).getImmutable();

        Element  r1 = bp.getZr().newRandomElement().getImmutable();
        Element  r2 = bp.getZr().newRandomElement().getImmutable();
        Element  hID1 = h1.mul(g.powZn(r1.invert()));
        Element ID1 = bp.getZr().newElementFromBytes(ID.getBytes()).getImmutable();
        Element  hID2 = h2.mul(g.powZn(r2.invert())).powZn(alpha.sub(ID1)).invert();



        Element[] yi = new Element[n];
        for (int i = 0; i < n; i++)
        {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            hID1 = hID1.powZn(yi[i]);
            hID2 = hID2.powZn(yi[i]);
            vPro.setProperty("y"+ID+i,yi[i].toString());}

        skProp.setProperty("r1"+ID,r1.toString());
        skProp.setProperty("r2"+ID,r2.toString());
        skProp.setProperty("hID1"+ID,hID1.toString());
        skProp.setProperty("hID2"+ID,hID2.toString());

        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }

    public static void ReKeyGen(String pairingFile,String skFile,String ID, String ID1)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties skProp =loadPropFromFile(skFile);
        String hID1str=skProp.getProperty("hID1"+ID);
        String hID2str=skProp.getProperty("hID1"+ID1);
        Element hID1 = bp.getZr().newElementFromBytes(hID1str.getBytes()).getImmutable();
        Element hID2 = bp.getZr().newElementFromBytes(hID2str.getBytes()).getImmutable();
        String rID1str=skProp.getProperty("r1"+ID);
        String rID2str=skProp.getProperty("r1"+ID1);
        Element rID1 = bp.getZr().newElementFromBytes(rID1str.getBytes()).getImmutable();
        Element rID2 = bp.getZr().newElementFromBytes(rID2str.getBytes()).getImmutable();

        Element rk1 = hID1.div(hID2);
        Element rk2 = rID1.div(rID2);

        skProp.setProperty("rk1",rk1.toString());
        skProp.setProperty("rk2",rk2.toString());

        storePropToFile(skProp, skFile);


    }

    public static void ReEnc(String paramsFile,String pairingFile,String skFile,String CTFile,String ID, String ID1)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties CTProp =loadPropFromFile(CTFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String rk1str=skProp.getProperty("rk1");
        Element rk1 = bp.getZr().newElementFromBytes(rk1str.getBytes()).getImmutable();
        String rk2str=skProp.getProperty("rk2");
        Element rk2 = bp.getG1().newElementFromBytes(rk2str.getBytes()).getImmutable();
        String C1str=CTProp.getProperty("C1"+ID);
        Element C1 = bp.getG1().newElementFromBytes(C1str.getBytes()).getImmutable();
        String C2str=CTProp.getProperty("C2"+ID);
        Element C2 = bp.getZr().newElementFromBytes(C2str.getBytes()).getImmutable();
        String Cxstr=CTProp.getProperty("Cx"+ID);
        Element Cx = bp.getZr().newElementFromBytes(Cxstr.getBytes()).getImmutable();
        String C3str=CTProp.getProperty("C3"+ID);
        Element C3 = bp.getZr().newElementFromBytes(C3str.getBytes()).getImmutable();
        Element C11 = C1;
        Element C21 = C2.powZn(rk1);
        Element Cx1 = Cx.mulZn(bp.pairing(C1,rk2));
        Element C31 = C3.mulZn(bp.pairing(g.powZn(rk1),g));

        CTProp.setProperty("C1"+ID1, C11.toString());
        CTProp.setProperty("C2"+ID1, C21.toString());
        CTProp.setProperty("C3"+ID1, C31.toString());
        CTProp.setProperty("Cx"+ID1, Cx1.toString());

        storePropToFile(CTProp, CTFile);


    }

    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String C1str=CTProp.getProperty("C1"+ID);
        Element C1 = bp.getG1().newElementFromBytes(C1str.getBytes()).getImmutable();
        String C2str=CTProp.getProperty("C2"+ID);
        Element C2 = bp.getZr().newElementFromBytes(C2str.getBytes()).getImmutable();
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String sstr=randomProp.getProperty("s");
        Element s = bp.getG1().newElementFromBytes(sstr.getBytes()).getImmutable();
        String h1str=PProp.getProperty("h1");
        Element h1 = bp.getG1().newElementFromBytes(h1str.getBytes()).getImmutable();
        String h2str=PProp.getProperty("h2");
        Element h2 = bp.getG1().newElementFromBytes(h2str.getBytes()).getImmutable();
        String rID1str=skProp.getProperty("r1"+ID);
        Element rID1 = bp.getG1().newElementFromBytes(rID1str.getBytes()).getImmutable();
        String rID2str=skProp.getProperty("r2"+ID);
        Element rID2 = bp.getG1().newElementFromBytes(rID2str.getBytes()).getImmutable();
        String hID1str=skProp.getProperty("hID1"+ID);
        Element hID1 = bp.getG1().newElementFromBytes(hID1str.getBytes()).getImmutable();
        String hID2str=skProp.getProperty("hID2"+ID);
        Element hID2 = bp.getG1().newElementFromBytes(hID2str.getBytes()).getImmutable();
        String g1str=PProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();


        Element[] x = new Element[n];
        Element[] y = new Element[n];
        Element[] y1 = new Element[n];
        Element sy = bp.pairing(g,h1).powZn(s.invert());
        double sum = 0.0, sum1 = 0.0;
        for(int i = 0; i < n; i++)
        {
            String xstr=vPro.getProperty("x"+i);
            String ystr=vPro.getProperty("y"+i);
            sum+=Double.valueOf(xstr)+Double.valueOf(ystr);

            x[i] = bp.getZr().newElementFromBytes(xstr.getBytes()).getImmutable();
            y[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();
            sy = sy.powZn(y[i]);
            C2 = C2.powZn(y[i]);
        }
        Element xy = bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable();

        Element C_xy = sy.mulZn(bp.pairing(g,g.powZn(xy)));
        Element XY = C_xy.mulZn(bp.pairing(C1,hID1)).mulZn(C2.mulZn(rID1));

        Element EM = bp.pairing(g,g).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (XY.isEqual(EM)) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        long start = System.currentTimeMillis();
        String dir = "./storeFile/Ours_File/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 50;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User1";
        String ID1="User2";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(30)+0;
            y[i] = rand.nextInt(30)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName, CTFileName, randomFileName, ID, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID,n);
        long end3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,ID1,n);
        System.out.println(end3-start3);
        long start4 = System.currentTimeMillis();
        ReKeyGen(pairingParametersFileName,skFileName,ID,ID1);
        long end4 = System.currentTimeMillis();
        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        ReEnc(ParameterFileName,pairingParametersFileName,skFileName,CTFileName,ID, ID1);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);
        long start6 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M,ID);
        long end6 = System.currentTimeMillis();
        System.out.println(end6-start6);
        long end = System.currentTimeMillis();
        System.out.println(end-start);
    }


}
