package Kim;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;


import static java.lang.System.out;

public class Kim {

    //初始阶段


    public static void setup(String pairingFile, String paramsFile,String mskFile, String vectorFile,int n) {
        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G1或者G2元素的对象
        Properties PProp =loadPropFromFile(paramsFile);
        Properties mskProp = loadPropFromFile(mskFile);  //定义一个对properties文件操作的对象
        Properties vPro = loadPropFromFile(vectorFile);
        String gstr=PProp.getProperty("g");
        String hstr=PProp.getProperty("h");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        Element alpha = bp.getZr().newRandomElement().getImmutable();
        Element[] a = new Element[n+1];
        Element[] gi = new Element[n+1];
        Element[] hi = new Element[n+1];
        mskProp.setProperty("alpha",alpha.toString());
        for (int  i = 0; i <= n; i++)
        {
            a[i] = bp.getZr().newRandomElement().getImmutable();
            hi[i] = h.powZn(a[i]);
            mskProp.setProperty("h"+i,hi[i].toString());
        }
        for(int i = 1; i <= n; i++)
        {
            gi[i] = g.powZn(a[i]);
            PProp.setProperty("g"+i, gi[i].toString());
        }


        //调用两次setup函数为了不代替之前的数据，用loadPropFromFile打开文件并直接取其中数据
        //设置主私钥

        Element X0 = bp.pairing(g,h);
        mskProp.setProperty("e",X0.toString());
        Element X1 = bp.pairing(g,hi[0]);
        PProp.setProperty("e0",X1.toString());



        storePropToFile(PProp,paramsFile);

        storePropToFile(mskProp, mskFile);
    }





    public static void Encryption(String pairingFile, String paramsFile, String vectorFile,String mskFile, String CTFile, String randomFile,int n, double[] x) throws NoSuchAlgorithmException {
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomPro = loadPropFromFile(randomFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        Element s = bp.getZr().newRandomElement().getImmutable();//从Zq上任选一个数

        Element []gi = new Element[n+1];
        for (int i = 1; i <= n; i++)
        {
            String g1str=PProp.getProperty("g"+i);
            gi[i] = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        }

        String h0str=mskProp.getProperty("h0");
        Element h0 = bp.getG1().newElementFromBytes(h0str.getBytes()).getImmutable();
        String e0str=PProp.getProperty("e0");
        Element e0 = bp.getG1().newElementFromBytes(e0str.getBytes()).getImmutable();

        Element C1 = g.powZn(s);
        Element [] C2 = new Element[n+1];

        Element[] xi = new Element[n];
        for (int i = 1; i <= n; i++)
        {
            xi[i-1] = bp.getZr().newElementFromBytes(String.valueOf(x[i-1]).getBytes()).getImmutable();
            vPro.setProperty("x"+i,xi[i-1].toString());
            C2[i] = g.powZn(xi[i-1]).mulZn(gi[i].powZn(s));
            CTProp.setProperty("C2"+i,C2[i].toString());
        }
        Element C3 = bp.pairing(g,h0).powZn(s);
        CTProp.setProperty("C1",C1.toString());

        CTProp.setProperty("C3",C3.toString());

        randomPro.setProperty("s", s.toString());

        storePropToFile(CTProp,CTFile);
        storePropToFile(randomPro,randomFile);
        storePropToFile(vPro, vectorFile);

    }
    public static void KGen(String pairingFile,String paramsFile,String mskFile,String vectorFile,String skFile,String randomFile,double[] y,int n, String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties mskProp = loadPropFromFile(mskFile);
        Properties randomProp =loadPropFromFile(randomFile);
        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr=PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        Element [] hi = new Element[n+1];
        for(int i = 0; i <= n; i++)
        {
            String h0str=mskProp.getProperty("h"+i);
            hi[i] = bp.getG1().newElementFromBytes(h0str.getBytes()).getImmutable();
        }
        String alphastr=mskProp.getProperty("alpha");
        Element alpha = bp.getG1().newElementFromBytes(alphastr.getBytes()).getImmutable();

        Element[] yi = new Element[n];
        yi[0] = bp.getZr().newElementFromBytes(String.valueOf(y[0]).getBytes()).getImmutable();
        Element R = bp.getZr().newElementFromBytes(String.valueOf(y[0]).getBytes()).getImmutable().powZn(alpha);
        vPro.setProperty("y0",yi[0].toString());

        for (int i = 1; i <= n; i++)
        {
            yi[i-1] = bp.getZr().newElementFromBytes(String.valueOf(y[i-1]).getBytes()).getImmutable();
            vPro.setProperty("y"+i,yi[i-1].toString());
            R = R.mulZn(yi[i-1].powZn(alpha));
        }

        Element k1 = hi[0];

        for (int i = 1; i <= n; i++)

            k1 = k1.mulZn(hi[i].powZn(yi[i-1].mul(R)));
        skProp.setProperty("k1",k1.toString());
        Element k2 = h.powZn(R);
        skProp.setProperty("k2",k2.toString());
        Element k3 = bp.pairing(g,h).powZn(R);
        skProp.setProperty("k3",k3.toString());
        randomProp.setProperty("R",R.toString());
        storePropToFile(randomProp,randomFile);
        storePropToFile(vPro, vectorFile);
        storePropToFile(skProp, skFile);


    }



    public static void Dec(String pairingFile,String paramsFile,String vectorFile,String skFile,String randomFile,String CTFile,int n, Double M,String ID)throws NoSuchAlgorithmException{
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties PProp =loadPropFromFile(paramsFile);
        Properties CTProp =loadPropFromFile(CTFile);
        Properties skProp =loadPropFromFile(skFile);
        Properties vPro = loadPropFromFile(vectorFile);
        Properties randomProp =loadPropFromFile(randomFile);

        String gstr=PProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String hstr=PProp.getProperty("h");
        Element h = bp.getG1().newElementFromBytes(hstr.getBytes()).getImmutable();
        String Rstr=randomProp.getProperty("R");
        Element R = bp.getG1().newElementFromBytes(Rstr.getBytes()).getImmutable();

        Element[] x = new Element[n];
        Element[] y = new Element[n];
        double sum = 0.0, sum1 = 0.0;
        for(int i = 0; i < n; i++)
        {
            String xstr=vPro.getProperty("x"+i);
            String ystr=vPro.getProperty("y"+i);
            sum+=Double.valueOf(xstr)+Double.valueOf(ystr);
            x[i] = bp.getZr().newElementFromBytes(xstr.getBytes()).getImmutable();
            y[i] = bp.getZr().newElementFromBytes(ystr.getBytes()).getImmutable();
        }

        Element xy = bp.getZr().newElementFromBytes(String.valueOf(sum).getBytes()).getImmutable();
        Element C1 = bp.getG1().newElementFromBytes(CTProp.getProperty("C1").getBytes()).getImmutable();
        Element[] C2 = new Element[n+1];
        for (int i = 1; i <= n; i++)
            C2[i] = bp.getG1().newElementFromBytes(CTProp.getProperty("C2"+i).getBytes()).getImmutable();
        Element C3 = bp.getG1().newElementFromBytes(CTProp.getProperty("C3").getBytes()).getImmutable();
        Element k1 = bp.getG1().newElementFromBytes(skProp.getProperty("k1").getBytes()).getImmutable();
        Element k2 = bp.getG1().newElementFromBytes(skProp.getProperty("k2").getBytes()).getImmutable();
        Element E = bp.pairing(C2[1].powZn(y[0]),k2);
        for (int i = 2; i <= n;i ++)
        {
            E = E.mul(bp.pairing(C2[i].powZn(y[i-1]),k2));
        }
        Element D = bp.pairing(C1,k1).invert().mulZn(E).mulZn(C3);

        Element EM = bp.pairing(g,g).powZn(bp.getZr().newElementFromBytes(String.valueOf(M).getBytes()).getImmutable());
        if (D.isEqual(bp.pairing(g,h).powZn(R.mulZn(EM)))) System.out.println("OK");

//        storePropToFile(randomProp,randomFile);

//        storePropToFile(skProp, skFile);


    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }



    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha0(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        /*
        指定配置文件的路径
         */
        String dir = "./storeFile/Kim/"; //根路径
        String pairingParametersFileName = dir + "a.properties";

        String ParameterFileName = dir + "params.properties";
        String mskFileName = dir + "msk.properties";
        String vectorFileName=dir+"vector.properties";

        String randomFileName=dir+"random.properties";
        String skFileName=dir+"sk.properties";
        String CTFileName=dir+"CT.properties";

        Random rand = new Random();

        int n = 10;
        double[] x = new double[n];
        double[] y = new double[n];
        String ID="User";
        Double M = 0.0;
        for (int i = 0; i < n; i++)
        {
            x[i] = rand.nextInt(30)+0;
            y[i] = rand.nextInt(30)+0;
            M+=x[i]*y[i];

        }
        System.out.println(M);
        long start1 = System.currentTimeMillis();
        setup(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,n);
        long end1 = System.currentTimeMillis();
        System.out.println(end1-start1);
        long start2 = System.currentTimeMillis();
        Encryption( pairingParametersFileName, ParameterFileName, vectorFileName,mskFileName, CTFileName, randomFileName, n, x);
        long end2 = System.currentTimeMillis();
        System.out.println(end2-start2);
        long start3 = System.currentTimeMillis();
        KGen(pairingParametersFileName,ParameterFileName,mskFileName,vectorFileName,skFileName,randomFileName,y,n,ID);
        long end3 = System.currentTimeMillis();
        System.out.println(end3-start3);

//        System.out.println(end4-start4);
        long start5 = System.currentTimeMillis();
        Dec(pairingParametersFileName,ParameterFileName,vectorFileName,skFileName,randomFileName,CTFileName,n,M, ID);
        long end5 = System.currentTimeMillis();
        System.out.println(end5-start5);

    }


}